class_name AttackComponent
extends Node

@export var movement_component: MovementComponent

@export_group("Combo Settings")
@export var combo_reset_time: float = 1.2
@export var attack_cooldown: float = 0.05

@export_group("Hitbox Areas")
@export var light1_area: Area2D
@export var light2_area: Area2D
@export var strong_area: Area2D

@onready var sprite: AnimatedSprite2D = $"../AnimatedSprite2D"

var current_attack: int = 0          # 1 or 2 for lights, 3 for strong
var next_light: int = 1              # toggles between 1 and 2
var last_attack_time: float = 0.0
var hit_objects: Array[Node2D] = []
var attack_facing_direction: float = 1.0

# This variable holds whichever area is currently being used
var attack_hitbox: Area2D 

func _ready():
	sprite.animation_finished.connect(_on_animation_finished)
	
	# Connect signals for all potential hitboxes
	if light1_area:
		light1_area.body_entered.connect(_on_hitbox_body_entered)
		light1_area.monitoring = false
	if light2_area:
		light2_area.body_entered.connect(_on_hitbox_body_entered)
		light2_area.monitoring = false
	if strong_area:
		strong_area.body_entered.connect(_on_hitbox_body_entered)
		strong_area.monitoring = false

func is_attacking() -> bool:
	if not sprite or not sprite.is_playing():
		return false
	return sprite.animation in ["attack1", "attack2", "attack3", "crouch_attack"]

func get_attack_facing_dir() -> float:
	return attack_facing_direction

func handle_attack(light_just_pressed: bool, strong_just_pressed: bool, delta: float) -> void:
	last_attack_time += delta

	# Reset combo if idle too long
	if not is_attacking() and last_attack_time > combo_reset_time and current_attack != 0:
		current_attack = 0
		next_light = 1
		_deactivate_hitbox()
		return

	# STRONG ATTACK
	if strong_just_pressed and sprite.animation != "attack3":
		start_attack(3)
		return

	# LIGHT ATTACK CHAIN
	if light_just_pressed:
		if not is_attacking():
			start_attack(next_light)
			return
		elif current_attack in [1, 2]:
			var next_one = 3 - current_attack
			start_attack(next_one)
			return

func start_attack(level: int) -> void:
	# First, shut down any existing hitbox before switching
	_deactivate_hitbox()
	
	current_attack = level
	
	# Assign the correct hitbox based on the attack level
	match level:
		1: attack_hitbox = light1_area
		2: attack_hitbox = light2_area
		3: attack_hitbox = strong_area

	var anim_name = "attack" + str(level)
	sprite.play(anim_name)

	last_attack_time = 0.0
	hit_objects.clear()
	_activate_hitbox()

	if movement_component:
		movement_component.can_move = false

	attack_facing_direction = 1.0 if not sprite.flip_h else -1.0

func _activate_hitbox() -> void:
	if attack_hitbox:
		attack_hitbox.monitoring = true

func _deactivate_hitbox() -> void:
	# Turn off the current hitbox
	if attack_hitbox:
		attack_hitbox.monitoring = false
	
	# Also safe-guard by turning off all assigned areas
	if light1_area: light1_area.monitoring = false
	if light2_area: light2_area.monitoring = false
	if strong_area: strong_area.monitoring = false
	
	hit_objects.clear()

func _on_animation_finished():
	if sprite.animation in ["attack1", "attack2"]:
		next_light = 3 - current_attack
		_deactivate_hitbox()
		current_attack = 0

	elif sprite.animation == "attack3":
		next_light = 1
		_deactivate_hitbox()
		current_attack = 0

	if movement_component:
		movement_component.can_move = true

func _on_hitbox_body_entered(body: Node2D) -> void:
	if body.has_method("take_damage") and body not in hit_objects:
		hit_objects.append(body)
		# Adjust damage based on attack type if desired
		var damage = 40 if current_attack == 3 else 25
		body.take_damage(damage, Vector2.ZERO)

func force_stop() -> void:
	sprite.stop()
	_on_animation_finished()
